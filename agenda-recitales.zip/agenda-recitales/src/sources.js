// LISTA DE FUENTES A VIGILAR
// Podés editar este archivo directamente en GitHub: al guardar, Cloudflare vuelve a publicar.
//
// Campos:
//   id        identificador corto, sin espacios ni tildes (no lo cambies después)
//   name      nombre para mostrar en el tablero
//   url       página a leer
//   parser    opcional: lector dedicado (livepass, enigma, tuentrada, venti).
//             Sin parser, se usan los datos estructurados de la página o la IA.
//   maxPages  opcional: cuántas páginas seguir si el lector sabe paginar (por defecto 1)
//   venue / city  opcionales: valores por defecto
//
// Fuentes tipo sitemap (para sitios cuya agenda no se puede leer pero sí cada evento):
//   type: "sitemap", url: dirección del sitemap, match: texto que tienen las URLs de
//   eventos (ej. "/evento/"), childMatch: filtro para sitemaps índice, perRun: cuántos
//   eventos nuevos revisar por corrida (por defecto 10).
//
// Las fuentes cuya url contiene "REEMPLAZAR" se ignoran.

export const SOURCES = [
  { id: "livepass",  name: "Livepass",  url: "https://livepass.com.ar/",        parser: "livepass" },
  { id: "enigma",    name: "Enigma",    url: "https://www.enigmatickets.com/",  parser: "enigma" },

  // Búsqueda de música, 6 eventos por página. En el plan gratis de Cloudflare
  // conviene no pasar de 3 páginas; con el plan pago podés subir a 30 o más.
  { id: "tuentrada", name: "TuEntrada", url: "https://tuentrada.com/busqueda?categoria=m%C3%BAsica",
    parser: "tuentrada", maxPages: 3 },

  // Sin lector dedicado todavía: usa la IA (muestra sobre todo los eventos del día).
  { id: "alpogo",    name: "Alpogo",    url: "https://alpogo.com/" },

  // Venti: su portada está bloqueada para bots, pero sus páginas de evento no.
  // Si su robots.txt indica un sitemap, pegá la dirección acá (ver README).
  { id: "venti", name: "Venti", type: "sitemap", url: "https://REEMPLAZAR-sitemap-de-venti.xml",
    match: "/evento/", parser: "venti", perRun: 10 },
];
