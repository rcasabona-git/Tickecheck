import { SOURCES } from "./sources.js";
import { prepare, extractEvents, clean } from "./extract.js";
import { PARSERS } from "./parsers.js";

// ---------- utilidades de fecha y texto ----------

// Argentina está en UTC-3 todo el año.
export const todayAR = () => new Date(Date.now() - 3 * 3600e3).toISOString().slice(0, 10);
const nowISO = () => new Date().toISOString();

const NOISE = /\b(en vivo|presenta|presentan|live|show|tour|gira|concierto|recital|feat|ft)\b/g;
const VENUE_NOISE = new Set(["teatro", "club", "estadio", "sala", "centro", "cultural", "the", "el", "la", "los", "las", "de"]);

export function slug(s = "") {
  return String(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
    .replace(NOISE, " ").replace(/[^a-z0-9]+/g, " ").trim();
}

// Huella para reconocer el mismo show publicado en distintas fuentes.
export function fingerprint(ev) {
  const artist = slug(ev.artist).split(" ").slice(0, 4).join("-");
  const venue = slug(ev.venue).split(" ").filter((w) => !VENUE_NOISE.has(w)).slice(0, 3).join("-");
  return `${ev.date}|${venue}|${artist}`;
}

async function sha256(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8" } });

// ---------- el agente ----------

const UA = "Mozilla/5.0 (compatible; AgendaRecitalesBot/1.0; uso personal)";
const PARSER_TEXT = 400_000; // los lectores dedicados reciben la página completa

async function runBatch(env, onlyId) {
  const active = SOURCES.filter((s) => s.url && !s.url.includes("REEMPLAZAR"));
  const { results } = await env.DB.prepare("SELECT * FROM source_status").all();
  const status = Object.fromEntries(results.map((r) => [r.source_id, r]));

  // Primero las que hace más tiempo que no se revisan.
  const queue = onlyId
    ? active.filter((s) => s.id === onlyId)
    : [...active].sort((a, b) =>
        (status[a.id]?.last_checked || "").localeCompare(status[b.id]?.last_checked || ""));

  const n = Math.max(1, parseInt(env.FUENTES_POR_CORRIDA || "2", 10));
  const ctx = { robots: new Map() };
  const report = [];
  for (const src of queue.slice(0, n)) report.push(await processSource(env, src, status[src.id], ctx));
  return report;
}

// ---------- robots.txt ----------
// Antes de pedir una página se revisa el robots.txt del sitio. Si prohíbe esa
// ruta para todos los bots, no se consulta.
async function robotsAllows(url, ctx) {
  const u = new URL(url);
  if (!ctx.robots.has(u.origin)) {
    let rules = [];
    try {
      const r = await fetch(`${u.origin}/robots.txt`, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(10_000) });
      if (r.ok) rules = parseRobots(await r.text());
    } catch { /* sin robots.txt: se permite */ }
    ctx.robots.set(u.origin, rules);
  }
  const path = u.pathname + u.search;
  let best = null;
  for (const rule of ctx.robots.get(u.origin)) {
    if (rule.re.test(path) && (!best || rule.len > best.len || (rule.len === best.len && rule.allow))) best = rule;
  }
  return !best || best.allow;
}

export function parseRobots(txt) {
  const rules = [];
  let agents = [], inGroup = false;
  for (const raw of txt.split(/\r?\n/)) {
    const line = raw.replace(/#.*/, "").trim();
    const m = line.match(/^([a-z-]+)\s*:\s*(.*)$/i);
    if (!m) continue;
    const key = m[1].toLowerCase(), val = m[2].trim();
    if (key === "user-agent") {
      if (inGroup) { agents = []; inGroup = false; }
      agents.push(val.toLowerCase());
    } else if (key === "allow" || key === "disallow") {
      inGroup = true;
      const applies = agents.includes("*") || agents.some((a) => a && "agendarecitalesbot".includes(a));
      if (!applies || (key === "disallow" && !val)) continue;
      const pattern = val.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\\\$$/, "$");
      rules.push({ allow: key === "allow", len: val.length, re: new RegExp("^" + pattern) });
    }
  }
  return rules;
}

async function fetchPage(url, ctx) {
  if (!(await robotsAllows(url, ctx))) throw new Error(`El robots.txt del sitio no permite leer ${new URL(url).pathname}`);
  const res = await fetch(url, {
    headers: { "User-Agent": UA, "Accept-Language": "es-AR,es;q=0.9" },
    signal: AbortSignal.timeout(20_000),
  });
  if (!res.ok) throw new Error(`${url} respondió con código ${res.status}`);
  return res.text();
}

async function saveStatus(env, src, checked, count, warning, hash) {
  await env.DB.prepare(
    `INSERT INTO source_status (source_id, last_checked, last_ok, events_found, error, content_hash)
     VALUES (?1, ?2, ?2, ?3, ?4, ?5)
     ON CONFLICT(source_id) DO UPDATE SET
       last_checked = ?2, last_ok = ?2, events_found = ?3, error = ?4, content_hash = ?5`
  ).bind(src.id, checked, count, warning, hash).run();
}

async function processSource(env, src, prev, ctx) {
  const checked = nowISO();
  try {
    if (src.type === "sitemap") return await processSitemap(env, src, prev, ctx, checked);

    // Leer la página (y las siguientes, si el lector sabe paginar).
    const parser = src.parser ? PARSERS[src.parser] : null;
    if (src.parser && !parser) throw new Error(`No existe el lector "${src.parser}"`);
    const today = todayAR();
    const pages = [], parsed = [];
    let url = src.url;
    for (let i = 0; url && i < (src.maxPages || 1); i++) {
      const page = prepare(await fetchPage(url, ctx), url, parser ? PARSER_TEXT : undefined);
      pages.push(page);
      if (!parser) break;
      const r = parser(page, { today, src });
      parsed.push(...r.events);
      url = r.next;
    }

    const hash = await sha256(pages.map((p) => JSON.stringify(p.jsonld) + p.text).join("|"));
    if (prev && prev.content_hash === hash && !prev.error) {
      await env.DB.prepare("UPDATE source_status SET last_checked = ?1 WHERE source_id = ?2").bind(checked, src.id).run();
      return { fuente: src.id, resultado: "sin cambios en la página" };
    }

    const events = parser ? clean(parsed, src, today) : await extractEvents(pages[0], src, env, today);
    const { nuevos, cambios } = await upsertEvents(env, src, events);

    let warning = null;
    if (events.length === 0 && (prev?.events_found || 0) > 0) {
      warning = `Devolvió 0 eventos (antes ${prev.events_found}). Puede que la página haya cambiado de diseño.`;
    } else if (events.length === 0 && parser) {
      warning = `El lector "${src.parser}" no encontró eventos. Revisá si la página cambió.`;
    }
    await saveStatus(env, src, checked, events.length, warning, warning ? null : hash);
    return { fuente: src.id, paginas: pages.length, eventos: events.length, nuevos, cambios, aviso: warning };
  } catch (e) {
    const msg = String(e?.message || e);
    await env.DB.prepare(
      `INSERT INTO source_status (source_id, last_checked, error) VALUES (?1, ?2, ?3)
       ON CONFLICT(source_id) DO UPDATE SET last_checked = ?2, error = ?3, content_hash = NULL`
    ).bind(src.id, checked, msg).run();
    return { fuente: src.id, error: msg };
  }
}

// ---------- modo sitemap ----------
// Lee el sitemap del sitio, detecta URLs de eventos que todavía no vio y entra
// solo a esas (unas pocas por corrida). Sirve para sitios cuya agenda no se
// puede leer pero sí sus páginas de evento. Solo detecta eventos nuevos, no
// cambios en los que ya conoce.
async function processSitemap(env, src, prev, ctx, checked) {
  const today = todayAR();
  let xml = await fetchPage(src.url, ctx);
  const locs = (x) => [...x.matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/g)].map((m) => m[1].replace(/&amp;/g, "&"));

  if (/<sitemapindex/i.test(xml)) {
    const children = locs(xml).filter((u) => !src.childMatch || u.includes(src.childMatch)).slice(0, 3);
    xml = "";
    for (const c of children) xml += await fetchPage(c, ctx);
  }
  const urls = [...new Set(locs(xml).filter((u) => !src.match || u.includes(src.match)))];

  const seen = new Set();
  for (let i = 0; i < urls.length; i += 90) {
    const chunk = urls.slice(i, i + 90);
    const { results } = await env.DB.prepare(
      `SELECT url FROM seen_urls WHERE url IN (${chunk.map(() => "?").join(",")})`
    ).bind(...chunk).all();
    for (const r of results) seen.add(r.url);
  }
  const fresh = urls.filter((u) => !seen.has(u));
  const batch = fresh.slice(0, src.perRun || 10);

  const parser = src.parser ? PARSERS[src.parser] : null;
  const found = [];
  for (const url of batch) {
    try {
      const page = prepare(await fetchPage(url, ctx), url);
      let evs = page.jsonld.length ? page.jsonld.map((e) => ({ ...e, url: e.url || url })) : [];
      if (!evs.length && parser) evs = parser(page, { today, src }).events;
      found.push(...evs);
    } catch { /* una página que falla no frena al resto */ }
    await env.DB.prepare("INSERT OR IGNORE INTO seen_urls (url, source_id, first_seen) VALUES (?1, ?2, ?3)")
      .bind(url, src.id, checked).run();
  }

  const events = clean(found, src, today);
  const { nuevos, cambios } = await upsertEvents(env, src, events);
  const pendientes = fresh.length - batch.length;
  const warning = urls.length === 0 ? "El sitemap no tiene URLs que coincidan con el filtro." : null;
  // El hash se guarda recién cuando no quedan URLs pendientes.
  await saveStatus(env, src, checked, (prev?.events_found || 0) + events.length, warning, null);
  return { fuente: src.id, urls_en_sitemap: urls.length, revisadas: batch.length, pendientes, nuevos, cambios };
}

// Guarda eventos nuevos y registra cambios en los existentes.
async function upsertEvents(env, src, events) {
  if (!events.length) return { nuevos: 0, cambios: 0 };
  const now = nowISO();

  // Si la misma fuente publica dos veces el mismo artista, lugar y día
  // (por ejemplo, dos funciones), se guardan como eventos distintos.
  const byId = new Map();
  for (const e of events) {
    let id = fingerprint(e);
    for (let k = 2; byId.has(id); k++) id = `${fingerprint(e)}|${k}`;
    byId.set(id, e);
  }
  const ids = [...byId.keys()];

  const existing = {};
  for (let i = 0; i < ids.length; i += 50) {
    const chunk = ids.slice(i, i + 50);
    const { results } = await env.DB.prepare(
      `SELECT * FROM events WHERE id IN (${chunk.map(() => "?").join(",")})`
    ).bind(...chunk).all();
    for (const r of results) existing[r.id] = r;
  }

  const stmts = [];
  const addChange = (id, kind, detail) =>
    stmts.push(env.DB.prepare("INSERT INTO changes (event_id, kind, detail, at) VALUES (?1, ?2, ?3, ?4)")
      .bind(id, kind, detail, now));
  let nuevos = 0, cambios = 0;

  for (const [id, e] of byId) {
    const old = existing[id];
    if (!old) {
      nuevos++;
      stmts.push(env.DB.prepare(
        `INSERT INTO events (id, artist, venue, city, date, time, price, url, status, source_id, sources, first_seen, last_seen, updated_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?12, ?12)`
      ).bind(id, e.artist, e.venue, e.city, e.date, e.time, e.price, e.url, e.status,
             src.id, JSON.stringify([src.id]), now));
      addChange(id, "nuevo", `Anunciado en ${src.name}`);
      continue;
    }

    // Precio y hora solo se comparan contra la misma fuente, para que dos sitios
    // que escriben el precio distinto no generen cambios falsos.
    const sameSource = old.source_id === src.id;
    const diffs = [];
    const statusChanged = e.status !== old.status &&
      (sameSource || ["agotado", "cancelado", "reprogramado"].includes(e.status));
    if (statusChanged) diffs.push(["estado", `${old.status} → ${e.status}`]);
    if (sameSource && e.price && old.price && e.price !== old.price) diffs.push(["precio", `${old.price} → ${e.price}`]);
    if (sameSource && e.time && old.time && e.time !== old.time) diffs.push(["hora", `${old.time} → ${e.time}`]);

    const sources = new Set(JSON.parse(old.sources || "[]"));
    sources.add(src.id);

    stmts.push(env.DB.prepare(
      `UPDATE events SET
         last_seen = ?2,
         status = ?3,
         price = CASE WHEN ?4 THEN COALESCE(NULLIF(?5, ''), price) ELSE COALESCE(NULLIF(price, ''), ?5) END,
         time  = CASE WHEN ?4 THEN COALESCE(NULLIF(?6, ''), time) ELSE COALESCE(NULLIF(time, ''), ?6) END,
         url   = COALESCE(NULLIF(url, ''), ?7),
         sources = ?8,
         updated_at = CASE WHEN ?9 THEN ?2 ELSE updated_at END
       WHERE id = ?1`
    ).bind(id, now, statusChanged ? e.status : old.status, sameSource ? 1 : 0, e.price, e.time, e.url,
           JSON.stringify([...sources]), diffs.length ? 1 : 0));

    for (const [kind, detail] of diffs) { cambios++; addChange(id, kind, detail); }
  }

  for (let i = 0; i < stmts.length; i += 100) await env.DB.batch(stmts.slice(i, i + 100));
  return { nuevos, cambios };
}

// ---------- API para el tablero ----------

function toCsv(rows) {
  const cols = ["date", "time", "artist", "venue", "city", "price", "status", "url", "first_seen"];
  const head = ["fecha", "hora", "artista", "venue", "ciudad", "precio", "estado", "link", "detectado"];
  const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [head.join(","), ...rows.map((r) => cols.map((c) => esc(r[c])).join(","))].join("\n");
}

export default {
  async scheduled(controller, env, ctx) {
    ctx.waitUntil(runBatch(env));
  },

  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    if (path === "/api/events" || path === "/api/events.csv") {
      const desde = url.searchParams.get("desde") || todayAR();
      const { results } = await env.DB.prepare(
        "SELECT * FROM events WHERE date >= ?1 ORDER BY date, time LIMIT 3000"
      ).bind(desde).all();
      if (path.endsWith(".csv")) {
        return new Response(toCsv(results), {
          headers: { "content-type": "text/csv; charset=utf-8" },
        });
      }
      return json(results);
    }

    if (path === "/api/changes") {
      const { results } = await env.DB.prepare(
        `SELECT c.kind, c.detail, c.at, e.artist, e.venue, e.date, e.url
         FROM changes c LEFT JOIN events e ON e.id = c.event_id
         ORDER BY c.id DESC LIMIT 150`
      ).all();
      return json(results);
    }

    if (path === "/api/sources") {
      const { results } = await env.DB.prepare("SELECT * FROM source_status").all();
      const st = Object.fromEntries(results.map((r) => [r.source_id, r]));
      return json(SOURCES.map((s) => ({
        ...s,
        pendiente: s.url.includes("REEMPLAZAR"),
        ...(st[s.id] || {}),
      })));
    }

    // Ejecución manual para probar: /api/run?key=TU_CLAVE  (opcional: &fuente=id)
    if (path === "/api/run") {
      if (!env.ADMIN_KEY || url.searchParams.get("key") !== env.ADMIN_KEY) {
        return json({ error: "Clave incorrecta o ADMIN_KEY no configurada" }, 401);
      }
      return json(await runBatch(env, url.searchParams.get("fuente")));
    }

    return new Response("No encontrado", { status: 404 });
  },
};
