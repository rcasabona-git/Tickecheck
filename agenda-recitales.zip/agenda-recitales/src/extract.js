// Convierte una página de agenda en una lista de eventos limpios.
//
// Estrategia:
//  1. Si la página trae datos estructurados (JSON-LD de schema.org, muy común en
//     ticketeras), se usan directamente: es gratis, rápido y exacto.
//  2. Si no, se convierte el HTML a texto y se le pide a un LLM que extraiga los eventos.

export const STATUSES = ["a_la_venta", "agotado", "cancelado", "reprogramado", "proximamente"];

const MAX_HTML = 600_000;   // no procesar páginas gigantes enteras
const MAX_TEXT = 24_000;    // texto que se le manda a la IA (~7-8k tokens)
const WORKERS_AI_MODEL = "@cf/meta/llama-3.3-70b-instruct-fp8-fast";
const CLAUDE_MODEL = "claude-haiku-4-5-20251001";

// ---------- 1. Preparación del HTML ----------

export function prepare(rawHtml, baseUrl, maxText = MAX_TEXT) {
  const html = rawHtml.slice(0, MAX_HTML);
  const og = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']*)["']/i);
  const tt = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = decodeEntities((og ? og[1] : tt ? tt[1] : "").trim());

  const jsonld = [];
  for (const m of html.matchAll(/<script[^>]*application\/ld\+json[^>]*>([\s\S]*?)<\/script>/gi)) {
    try { collectJsonLdEvents(JSON.parse(m[1].trim()), jsonld); } catch { /* JSON roto: se ignora */ }
  }

  let t = html.replace(/<(script|style|noscript|svg|head|iframe|template)\b[\s\S]*?<\/\1>/gi, " ");
  // Conservar los links (sirven para el link de entradas): "texto [https://...]"
  t = t.replace(/<a\s[^>]*href=["']([^"'#][^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi,
    (_, href, inner) => ` ${inner.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim()} [${absolute(href, baseUrl)}] `);
  t = t.replace(/<(br|\/p|\/div|\/li|\/h\d|\/tr|\/article|\/section)[^>]*>/gi, "\n")
       .replace(/<[^>]+>/g, " ");
  t = decodeEntities(t).replace(/[ \t\u00a0]+/g, " ").replace(/\n\s*\n+/g, "\n").trim();

  return { url: baseUrl, title, jsonld, text: t.slice(0, maxText) };
}

function collectJsonLdEvents(node, out) {
  if (!node || typeof node !== "object") return;
  if (Array.isArray(node)) return node.forEach((n) => collectJsonLdEvents(n, out));
  if (node["@graph"]) collectJsonLdEvents(node["@graph"], out);
  const types = [].concat(node["@type"] || []);
  if (types.some((t) => /Event$/.test(t)) && node.startDate) {
    const start = toArgentina(String(node.startDate));
    const offers = [].concat(node.offers || [])[0] || {};
    const performer = [].concat(node.performer || [])[0];
    const status = String(node.eventStatus || "");
    const avail = String(offers.availability || "");
    const price = offers.price ?? offers.lowPrice;
    out.push({
      artist: performer?.name || node.name,
      date: start.slice(0, 10),
      time: start.length >= 16 ? start.slice(11, 16) : "",
      venue: node.location?.name || "",
      city: node.location?.address?.addressLocality || "",
      price: price != null ? `${offers.priceCurrency || "$"} ${price}` : "",
      url: node.url || offers.url || "",
      status: /Cancel/.test(status) ? "cancelado"
        : /Resched|Postpon/.test(status) ? "reprogramado"
        : /SoldOut/.test(avail) ? "agotado"
        : /PreOrder|PreSale/.test(avail) ? "proximamente"
        : "a_la_venta",
    });
  }
}

// ---------- 2. Extracción ----------

// Las fechas con zona horaria ("...Z" o "+00:00") se pasan a hora argentina (UTC-3).
function toArgentina(s) {
  if (!/(Z|[+-]\d{2}:?\d{2})$/.test(s) || s.length < 16) return s;
  const d = new Date(s);
  if (isNaN(d)) return s;
  return new Date(d.getTime() - 3 * 3600e3).toISOString().slice(0, 16);
}

export async function extractEvents(prepared, src, env, today) {
  let events;
  if (prepared.jsonld.length) {
    events = prepared.jsonld;
  } else if (prepared.text.length < 200) {
    // Página casi vacía: probablemente carga todo con JavaScript.
    throw new Error("La página no tiene texto legible (probablemente se arma con JavaScript).");
  } else {
    events = env.ANTHROPIC_API_KEY
      ? await extractWithClaude(prepared.text, src, env, today)
      : await extractWithWorkersAI(prepared.text, src, env, today);
  }
  return clean(events, src, today);
}

const SCHEMA = {
  type: "object",
  properties: {
    events: {
      type: "array",
      items: {
        type: "object",
        properties: {
          artist: { type: "string" },
          date: { type: "string", description: "AAAA-MM-DD" },
          time: { type: "string", description: "HH:MM o vacío" },
          venue: { type: "string" },
          city: { type: "string" },
          price: { type: "string" },
          url: { type: "string" },
          status: { type: "string", enum: STATUSES },
        },
        required: ["artist", "date"],
      },
    },
  },
  required: ["events"],
};

function buildPrompt(text, src, today) {
  const system = `Sos un asistente que extrae la agenda de recitales y eventos en vivo de páginas web argentinas.
Hoy es ${today}. Devolvé SOLO un objeto JSON con la forma {"events":[...]}.
Reglas:
- Un elemento por cada función (si un artista toca dos fechas, son dos elementos).
- "artist": nombre del artista o del evento, sin agregados como "en vivo" o "presenta".
- "date" en formato AAAA-MM-DD. Si la página no dice el año, usá el próximo año en que esa fecha no haya pasado.
- "time" en HH:MM de 24 horas, o "" si no figura.
- "venue": lugar donde se hace.${src.venue ? ` Si no se aclara, es "${src.venue}".` : ""}
- "price": tal como aparece (ej. "$25.000"), o "".
- "url": el link de compra de entradas o del evento, completo, o "".
- "status": uno de ${STATUSES.join(", ")}. Usá "agotado" si dice sold out o agotado.
- Ignorá eventos pasados, menús, noticias y publicidad. No inventes datos: si algo no está, dejalo vacío.
- Si no hay eventos, devolvé {"events":[]}.`;
  const user = `Fuente: ${src.name}\nURL: ${src.url}\n\nContenido de la página:\n${text}`;
  return { system, user };
}

async function extractWithWorkersAI(text, src, env, today) {
  const { system, user } = buildPrompt(text, src, today);
  const r = await env.AI.run(WORKERS_AI_MODEL, {
    messages: [{ role: "system", content: system }, { role: "user", content: user }],
    response_format: { type: "json_schema", json_schema: SCHEMA },
    max_tokens: 4096,
  });
  const out = typeof r.response === "string" ? parseJson(r.response) : r.response;
  return out?.events || [];
}

async function extractWithClaude(text, src, env, today) {
  const { system, user } = buildPrompt(text, src, today);
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model: CLAUDE_MODEL,
      max_tokens: 8000,
      system,
      messages: [{ role: "user", content: user }],
    }),
  });
  if (!res.ok) throw new Error(`Error de la API de Claude: ${res.status}`);
  const data = await res.json();
  const txt = (data.content || []).map((c) => c.text || "").join("");
  return parseJson(txt)?.events || [];
}

// ---------- 3. Limpieza y validación ----------

export function clean(events, src, today) {
  const seen = new Set();
  const out = [];
  for (const e of events.slice(0, 1000)) {
    const artist = str(e.artist);
    const date = str(e.date);
    if (!artist || !/^\d{4}-\d{2}-\d{2}$/.test(date) || date < today) continue;
    const ev = {
      artist,
      date,
      time: /^\d{1,2}:\d{2}$/.test(str(e.time)) ? str(e.time).padStart(5, "0") : "",
      venue: str(e.venue) || src.venue || "",
      city: str(e.city) || src.city || "",
      price: str(e.price),
      url: /^https?:\/\//.test(str(e.url)) ? str(e.url) : "",
      status: STATUSES.includes(e.status) ? e.status : "a_la_venta",
    };
    const key = `${ev.date}|${ev.time}|${ev.artist}|${ev.venue}|${ev.url}`;
    if (!seen.has(key)) { seen.add(key); out.push(ev); }
  }
  return out;
}

// ---------- utilidades ----------

const str = (v) => (v == null ? "" : String(v).trim());

function parseJson(txt) {
  const s = txt.indexOf("{"), e = txt.lastIndexOf("}");
  if (s < 0 || e < s) return null;
  try { return JSON.parse(txt.slice(s, e + 1)); } catch { return null; }
}

function absolute(href, base) {
  try { return new URL(href, base).href; } catch { return href; }
}

function decodeEntities(s) {
  const map = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " ", aacute: "á", eacute: "é",
    iacute: "í", oacute: "ó", uacute: "ú", ntilde: "ñ", Aacute: "Á", Eacute: "É", Iacute: "Í",
    Oacute: "Ó", Uacute: "Ú", Ntilde: "Ñ", uuml: "ü", ndash: "–", mdash: "—", hellip: "…", iexcl: "¡", iquest: "¿" };
  return s
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&([a-z]+);/gi, (m, n) => map[n] ?? m);
}
