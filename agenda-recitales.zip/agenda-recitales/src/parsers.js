// Lectores dedicados: sacan los eventos directamente del formato de cada página,
// sin IA. Son más rápidos, gratis y no se cortan con agendas largas.
//
// Cada lector recibe la página ya preparada por prepare() (texto con los links
// como "texto [https://...]") y devuelve { events, next }:
//   events: lista de eventos crudos (después pasan por clean())
//   next:   URL de la página siguiente, o null
//
// Si una ticketera cambia el diseño, el lector devuelve 0 eventos y el tablero
// muestra el aviso en "Fuentes". Ahí hay que ajustar la expresión regular.

const MESES = { ene: 1, feb: 2, mar: 3, abr: 4, may: 5, jun: 6, jul: 7, ago: 8, sep: 9, set: 9, oct: 10, nov: 11, dic: 12 };
const MES_LARGO = { enero: 1, febrero: 2, marzo: 3, abril: 4, mayo: 5, junio: 6, julio: 7, agosto: 8,
  septiembre: 9, setiembre: 9, octubre: 10, noviembre: 11, diciembre: 12 };

// Ciudad según el nombre del lugar, para las ticketeras que no la informan.
const CIUDADES = [
  ["café berlín", "CABA"], ["cafe berlin", "CABA"], ["ccnu", "CABA"], ["club re", "Quilmes"], ["quilmes", "Quilmes"],
  ["san miguel", "San Miguel"], ["ópera lp", "La Plata"], ["opera lp", "La Plata"], ["teatro argentino", "La Plata"],
  ["hipódromo de la plata", "La Plata"], ["guajira lp", "La Plata"], ["estadio uno", "La Plata"], ["la plata", "La Plata"],
  ["huracán", "CABA"], ["vorterix", "CABA"], ["malba", "CABA"], ["teatro colón", "CABA"], ["gran rex", "CABA"],
  ["deseo club", "CABA"], ["club ciudad", "CABA"], ["margarita xirgu", "CABA"], ["niceto", "CABA"], ["buenos aires", "CABA"],
  ["rosario", "Rosario"], ["córdoba", "Córdoba"], ["cordoba", "Córdoba"], ["neuquén", "Neuquén"],
  ["bahía blanca", "Bahía Blanca"], ["mar del plata", "Mar del Plata"], ["mardel", "Mar del Plata"],
];
export function cityFor(venue = "") {
  const v = venue.toLowerCase();
  for (const [k, c] of CIUDADES) if (v.includes(k)) return c;
  return "";
}

// Año para fechas sin año: el próximo en que la fecha no haya pasado.
export function isoDate(day, month, today, year) {
  const [ty, tm, td] = today.split("-").map(Number);
  let y = year || ty;
  if (!year && (month < tm || (month === tm && day < td))) y = ty + 1;
  return `${y}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

const pad = (h, m) => `${String(h).padStart(2, "0")}:${m}`;

// "Artista en el Lugar" -> { artist, venue }
function splitEn(title) {
  const i = title.lastIndexOf(" en ");
  if (i < 0) return { artist: title.trim(), venue: "" };
  return { artist: title.slice(0, i).trim(), venue: title.slice(i + 4).replace(/^(el|la|los|las) /i, "").trim() };
}

// ---------- Livepass ----------
// Portada: cada evento es un link "19 SEP ARTISTA en LUGAR [https://livepass.com.ar/events/...]".
function livepass(page, { today }) {
  const re = /(\d{1,2}) (ENE|FEB|MAR|ABR|MAY|JUN|JUL|AGO|SEP|OCT|NOV|DIC)(?: al \d{1,2} [A-Z]{3})? ([^\[\]\n]+?) \[(https:\/\/livepass\.com\.ar\/events\/[^\]\s?]+)[^\]]*\]/g;
  const byUrl = new Map();
  for (const m of page.text.matchAll(re)) {
    const url = m[4];
    if (byUrl.has(url)) continue;
    const date = isoDate(+m[1], MESES[m[2].toLowerCase()], today);
    const { artist, venue } = splitEn(m[3]);
    // Muchos links incluyen fecha y hora: ...-2026-10-09-23-00-00-0300
    const t = url.match(/(\d{4})-(\d{2})-(\d{2})-(\d{2})-(\d{2})-\d{2}/);
    const time = t && `${t[1]}-${t[2]}-${t[3]}` === date ? `${t[4]}:${t[5]}` : "";
    byUrl.set(url, { artist, venue, city: cityFor(venue), date, time, url, status: "a_la_venta" });
  }
  return { events: [...byUrl.values()], next: null };
}

// ---------- Enigma ----------
// Portada: cada tarjeta es un link vacío a /event/<id>, seguido del nombre,
// la fecha ("Sáb 28/11 + Dom 29/11", "Jue 24/09 20:00hs") y el lugar.
function enigma(page, { today }) {
  const events = [];
  const parts = page.text.split(/\[(https:\/\/www\.enigmatickets\.com\/event\/[0-9a-f-]{36})\]/);
  for (let i = 1; i < parts.length; i += 2) {
    const url = parts[i];
    const lines = parts[i + 1].split("\n").map((l) => l.trim()).filter(Boolean).slice(0, 4);
    if (!lines.length) continue;
    const artist = lines[0].replace(/\s*\[https?:[^\]]*\]/g, "").trim();
    const dateLine = lines.slice(1).find((l) => /\d/.test(l) && !/\[https?:/.test(l)) || "";
    const venueLine = lines.slice(1).find((l) => /\[https:\/\/www\.enigmatickets\.com\/(?!event\/)/.test(l)) || "";
    const venue = venueLine.replace(/\s*\[https?:[^\]]*\]/g, "").trim();

    let date = "", time = "";
    const dm = dateLine.match(/(\d{1,2})\/(\d{1,2})/);
    const named = dateLine.match(/^(\d{1,2})\b[^\n]*?\bde\s+([a-záéíóú]+)/i);
    if (dm) date = isoDate(+dm[1], +dm[2], today);
    else if (named && !/^desde/i.test(dateLine) && MES_LARGO[named[2].toLowerCase()]) {
      date = isoDate(+named[1], MES_LARGO[named[2].toLowerCase()], today);
    }
    const tm = dateLine.match(/(\d{1,2}):(\d{2})\s*hs/i);
    if (tm) time = pad(tm[1], tm[2]);
    if (!date) continue; // "Próximamente" o sin fecha concreta
    events.push({ artist, venue, city: cityFor(venue), date, time, url, status: "a_la_venta" });
  }
  return { events, next: null };
}

// ---------- TuEntrada ----------
// Búsqueda por categoría, paginada de a 6. Cada tarjeta:
// "NOMBRE NOMBRE Disponible 19-09-2026 20:30 hs Teatro Gran Rex, Buenos Aires Más información [url]"
const TE_STATUS = { "disponible": "a_la_venta", "últimas entradas": "a_la_venta", "agotado": "agotado",
  "próximamente": "proximamente", "cancelado": "cancelado", "suspendido": "cancelado" };
function tuentrada(page, { today }) {
  const re = /([^\[\]\n]+?)\s+(Disponible|Últimas Entradas|Agotado|Próximamente|Cancelado|Suspendido)\s+(?:Del\s+)?(\d{2})-(\d{2})-(\d{4})(?:\s+(\d{2}):(\d{2})\s*hs)?(?:\s+al\s+\d{2}-\d{2}-\d{4})?\s*([^\[\]\n]*?)\s*Más información\s*\[(https?:\/\/[^\]\s]+)\]/gi;
  const events = [];
  for (const m of page.text.matchAll(re)) {
    let name = m[1].trim();
    // El nombre viene repetido ("Vico C Vico C"): nos quedamos con una copia.
    const half = name.length / 2;
    if (Number.isInteger(half - 0.5) && name.slice(0, half - 0.5) === name.slice(half + 0.5)) name = name.slice(0, half - 0.5);
    let venue = m[8].trim(), city = "";
    const comma = venue.lastIndexOf(",");
    if (comma > 0) { city = venue.slice(comma + 1).trim(); venue = venue.slice(0, comma).trim(); }
    if (/^buenos aires$/i.test(city)) city = "CABA";
    if (/^tour$/i.test(venue)) venue = "Gira";
    events.push({
      artist: name, venue, city: city || cityFor(venue),
      date: isoDate(+m[3], +m[4], today, +m[5]),
      time: m[6] ? `${m[6]}:${m[7]}` : "",
      url: m[9], status: TE_STATUS[m[2].toLowerCase()] || "a_la_venta",
    });
  }
  const next = page.text.match(/Siguiente\s*\[(https?:\/\/[^\]\s]*cursor=[^\]\s]+)\]/);
  return { events, next: next ? next[1] : null };
}

// ---------- Venti (páginas de evento sueltas, para el modo sitemap) ----------
// El título de cada página: "Compra tus entradas para NOMBRE en Venti | 26 de nov de 2026 | LUGAR"
function venti(page, { today }) {
  const m = (page.title || "").match(/Compra tus entradas para (.+?) en Venti \| (\d{1,2}) de ([a-zé]+)\.? de (\d{4}) \| (.+)$/i);
  if (!m) return { events: [], next: null };
  const month = MESES[m[3].toLowerCase().slice(0, 3)];
  if (!month) return { events: [], next: null };
  const venue = m[5].trim();
  return {
    events: [{ artist: m[1].trim(), venue, city: cityFor(venue), date: isoDate(+m[2], month, today, +m[4]),
      time: "", url: page.url, status: "a_la_venta" }],
    next: null,
  };
}

export const PARSERS = { livepass, enigma, tuentrada, venti };
