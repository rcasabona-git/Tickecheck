-- Pegá todo esto en la consola de tu base D1 (una sola vez).

CREATE TABLE IF NOT EXISTS events (
  id          TEXT PRIMARY KEY,      -- huella: fecha|venue|artista
  artist      TEXT NOT NULL,
  venue       TEXT,
  city        TEXT,
  date        TEXT NOT NULL,         -- AAAA-MM-DD
  time        TEXT,                  -- HH:MM
  price       TEXT,
  url         TEXT,
  status      TEXT DEFAULT 'a_la_venta',
  source_id   TEXT,                  -- primera fuente donde apareció
  sources     TEXT,                  -- todas las fuentes (JSON)
  first_seen  TEXT,
  last_seen   TEXT,
  updated_at  TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_date ON events(date);

CREATE TABLE IF NOT EXISTS changes (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  event_id  TEXT,
  kind      TEXT,                    -- nuevo, estado, precio, hora
  detail    TEXT,
  at        TEXT
);

CREATE TABLE IF NOT EXISTS source_status (
  source_id     TEXT PRIMARY KEY,
  last_checked  TEXT,
  last_ok       TEXT,
  events_found  INTEGER DEFAULT 0,
  error         TEXT,
  content_hash  TEXT
);

-- Modo sitemap: URLs de eventos ya revisadas.
CREATE TABLE IF NOT EXISTS seen_urls (
  url         TEXT PRIMARY KEY,
  source_id   TEXT,
  first_seen  TEXT
);
